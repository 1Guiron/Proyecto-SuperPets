/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SuperPets;
import java.util.Scanner;
/**
 *
 * @author Colop
 */
public class Menu {

    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Menu");
        System.out.println("1. Modo Arena");
        System.out.println("2. Modo Versus");
      
        int opcion= entrada.nextInt();
         Pelea para = new Pelea();
        switch (opcion) {
            case 1:
               
                para.modoArena();
                break;
            case 2:
                para.modoVersus();
                break;
            
            default:
                System.out.println("Opcion inexistente");
                break;
        }
    }
    
}
