
package SuperPets;

/**
 *
 * @author Colop
 */
public class ModoArena extends ResultadoPelea {
    public ModoArena(Mascotas[] jugador1, Mascotas[] jugador2, int ronda, int partidasGanadas, int partidasPerdidas, int vida){
        super(jugador1,jugador2,ronda,partidasGanadas, partidasPerdidas, vida);
    }
   
   public void Derrota(){
       Pelea conectar = new Pelea();
        conectar.misMascotas=jugador1;
        conectar.ronda=ronda;
        conectar.partidasGanadas=partidasGanadas;
        conectar.partidasPerdidas=partidasPerdidas;
        conectar.vida=vida;
        
        if(ronda==1||ronda==2||ronda==3){
            conectar.vida--;
        }
        else if(ronda==4||ronda==5||ronda==6){
            conectar.vida=vida-2;
        }
        else if(ronda>=7){
            conectar.vida=vida-3;
        }
        
        System.out.println("Perdiste");
        if(conectar.vida<=0){
          System.out.println("No te quedan vidas");
        }
        else{
           
            conectar.modoArena(); 
        }
    }
    public void Victoria(){
        Pelea conectar = new Pelea();
        conectar.misMascotas=jugador1;
        conectar.ronda=ronda;
        conectar.partidasGanadas=partidasGanadas;
        conectar.partidasPerdidas=partidasPerdidas;
       
        System.out.println("Ganaste");
        if(partidasGanadas==3){
            System.out.println("Pasaste");
        }else{
            
            conectar.modoArena();
        }
    }
    public void Empate(){
        Pelea conectar = new Pelea();
        conectar.misMascotas=jugador1;
        conectar.ronda=ronda;
        conectar.partidasGanadas=partidasGanadas;
        conectar.partidasPerdidas=partidasPerdidas;
        
        System.out.println("Empate");
        conectar.modoArena();
    }
    
}
