
package SuperPets;

public class Pelea {
   protected Mascotas[] misMascotas;
   protected Mascotas[] rival;
   protected Mascotas[] clonacion;
   
   static int ronda=1;
   static int partidasPerdidas=0;
   static int partidasGanadas=0;
   static int envio=0;
   static int vida=10;
   
    public Pelea() {
        this.misMascotas = new Mascotas[5];
        this.rival= new Mascotas[5];
    }
    public void modoArena(){
        
        Tienda conectar = new Tienda();
        if(ronda==1){
        for(int j=0;j<5;j++){
            misMascotas[j]=null;
         }
        }
        System.out.println("");
        System.out.println("Ronda: "+ronda);
        conectar.mascotasDisponibles();
        conectar.mascotasMostradas();
        misMascotas=conectar.mascotasCompradas(misMascotas);
        rival=conectar.iaMascotas();
        ronda++;
        envio=1;
        clonacion=clonar(misMascotas);
        pelea(clonacion,rival,envio);
        
    }
    public Mascotas[] clonar(Mascotas[] misMascotas){
        
         Mascotas[] clonacion= new Mascotas[5];
         for(int j=0;j<5;j++){
             if(misMascotas[j]!=null){
                 try {
                     clonacion[j]= (Mascotas) misMascotas[j].clone();
                 } catch (CloneNotSupportedException e) {
                     e.printStackTrace();
                 }
             }
         }
         
         return clonacion;
    }
    public void modoVersus(){
        
        Tienda conectar = new Tienda();
        if(ronda==1){
        for(int j=0;j<5;j++){
            misMascotas[j]=null;
         }
        for(int k=0;k<5;k++){
            rival[k]=null;
         }
        }
        System.out.println("");
        System.out.println("Ronda: "+ronda);
        conectar.mascotasDisponibles();
        conectar.mascotasMostradas();
        System.out.println("JUGADOR 1");
        misMascotas=conectar.mascotasCompradas(misMascotas);
        System.out.println("");
        System.out.println("JUGADOR 2");
        conectar.mascotasMostradas();
        rival=conectar.mascotasCompradas(rival);
        ronda++;
        
       pelea(misMascotas,rival,2);
        
    }
    public void pelea(Mascotas[] jugador1,Mascotas[] jugador2,int u){
       
       
        int vidaJg,vidaIa;
        int dañoJg,dañoIa;
        int a=0,b=0;
        int x=0,y=0;
        int contadorMascotasJg2=0, contadorMascotasJg=0;
        
        for(Mascotas ir:jugador1){
            if(ir!=null){
                contadorMascotasJg++;
            }
        }
        for(Mascotas ir:jugador2){
            if(ir!=null){
                contadorMascotasJg2++;
            }
        }
        System.out.println("Pelea "+(ronda-1));
        boolean prueba= true;
        while(prueba==true){
          
           vidaJg =jugador1[a].vida();
           dañoJg=jugador1[a].daño();
           vidaIa=jugador2[b].vida();
           dañoIa=jugador2[b].daño();
           
          jugador1[a].setNom(vidaJg-dañoIa);
          jugador2[b].setNom(vidaIa-dañoJg);
          try {
            //retraso de 1 segundo
            Thread.sleep(1000);
         } catch (Exception e) {
            System.out.println(e);
         }
          jugador1[a].Mostrar();
          jugador2[b].Mostrar();
         
           if(jugador1[a].vida()<=0){
               System.out.println(jugador1[a].obtenerNombre()+" de Jugador1 abatido");
               if((a+1)!=contadorMascotasJg){
                 a=a+1;
                
               }
                x++;
           }  
           if(jugador2[b].vida()<=0){
               System.out.println(jugador2[b].obtenerNombre()+" de Jugador2 abatido");
             if((b+1)!=contadorMascotasJg2){
                 b=b+1; 
                
               }   
                y++; 
           }
             if((x==contadorMascotasJg) ||(y== contadorMascotasJg2)){
                prueba=false;
              }
        }
        
       
       
        if(x==contadorMascotasJg&&y==contadorMascotasJg2 ){
         switch(u){
             case 1: 
                 ResultadoPelea ir = new ModoArena(misMascotas,rival,ronda,partidasGanadas,partidasPerdidas,vida);
                 ir.Empate();
                 break;
             case 2: 
                 ResultadoPelea ir1 = new ModoVersus(misMascotas,rival,ronda,partidasGanadas,partidasPerdidas,vida);
                 ir1.Empate();
                 break;
             default:
                 break;
         }
        }
        else if(y==contadorMascotasJg2){
             partidasPerdidas++;
             switch(u){
             case 1: 
                
                 ResultadoPelea ir = new ModoArena(misMascotas,rival,ronda,partidasGanadas,partidasPerdidas,vida);
                 ir.Victoria();
                 break;
             case 2: 
                 ResultadoPelea ir1 = new ModoVersus(misMascotas,rival,ronda,partidasGanadas,partidasPerdidas,vida);
                 ir1.Victoria();
                 break;
             default:
                 break;
         }
        }
        else if(x==contadorMascotasJg){
            partidasPerdidas++;
          switch(u){
             case 1: 
                 ResultadoPelea ir = new ModoArena(misMascotas,rival,ronda,partidasGanadas,partidasPerdidas,vida);
                 ir.Derrota();
                 break;
             case 2: 
                 ResultadoPelea ir1 = new ModoVersus(misMascotas,rival,ronda,partidasGanadas,partidasPerdidas,vida);
                 ir1.Derrota();
                 break;
             default:
                 break;
         }
        }
        else{
            System.out.println("aaaaaaaaaaa");
        }
         
    }
  
}
