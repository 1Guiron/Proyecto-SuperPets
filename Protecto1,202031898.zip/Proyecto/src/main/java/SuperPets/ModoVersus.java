/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SuperPets;

/**
 *
 * @author Colop
 */
public class ModoVersus extends ResultadoPelea {
    public ModoVersus(Mascotas[] jugador1, Mascotas[] jugador2, int ronda, int partidasGanadas, int partidasPerdidas, int vida){
        super(jugador1,jugador2,ronda,partidasGanadas, partidasPerdidas,vida);
    }
   public void Derrota(){
    
    }
    public void Victoria(){
     
    }
    public void Empate(){
        
    }
    
}
