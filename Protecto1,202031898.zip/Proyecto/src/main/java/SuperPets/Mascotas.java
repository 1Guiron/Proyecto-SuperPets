
package SuperPets;

public class Mascotas implements Cloneable {
   
    private String nombre;
    private int unidadDeVida;
    private int unidadDeDaño;
    private double nivelDeMascota;
   
    public Mascotas(String nombre, int unidadDeDaño, int unidadDeVida, double nivelDeMascota){

       this.nombre=nombre;
       this.unidadDeDaño=unidadDeDaño;
       this.unidadDeVida=unidadDeVida;
       this.nivelDeMascota=nivelDeMascota;
    }
    @Override
    public String toString(){
      return String.format(
         "Mascota: %s, Vida: %s, Daño: %s, Nivel: %s",
          nombre,
          unidadDeVida,
          unidadDeDaño,
          nivelDeMascota);
    }
     public void Mostrar(){
       System.out.println(toString());
        
    }
     public String obtenerNombre() {
         
        return nombre;
    }
    public boolean tieneNombre(String compararNombre) {
        return nombre.equals(compararNombre);
    }
    public int daño(){
        return unidadDeDaño;
    }
    public void setNom(int vida) {
        this.unidadDeVida = vida;
    }
    public double nivel(){
        return nivelDeMascota;
    }
    public void setNivel(double nivel) {
        this.nivelDeMascota = nivel;
    }
   public int vida(){
        return unidadDeVida;
    }
   public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
