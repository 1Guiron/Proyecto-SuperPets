
package SuperPets;
import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;

public class Tienda {
   int oro=10;
   static int comprar = 3;
   static int vender=1;
   static int aux;
   static int[] Datos=new int[3];
   static Mascotas[] lista2;
   static String[] listacomida;
   
   public Mascotas baseMascotas(int a){
        Mascotas[] lista= new Mascotas[100];
        lista[0]= new Mascotas("Hormiga",2,1,1);
        lista[1]= new Mascotas("Pescado",2,3,1);
        lista[2]= new Mascotas("Mosquito",2,2,1);
        lista[3]= new Mascotas("Grillo",1,2,1);
        lista[4]= new Mascotas("Castor",2,2,1);
        lista[5]= new Mascotas("Caballo",2,1,1);
        lista[6]= new Mascotas("Nutria",1,2,1);
        lista[7]= new Mascotas("Escarabajo",2,3,1);
        lista[8]= new Mascotas("Sapo",3,3,1);
        lista[9]= new Mascotas("Dodo",2,3,1);
        lista[10]= new Mascotas("Elefante",3,5,1);
        lista[11]= new Mascotas("PuercoEspin",3,2,1);
        lista[12]= new Mascotas("Pavoreal",2,5,1);
        lista[13]= new Mascotas("Rata",4,5,1);
        lista[14]= new Mascotas("Zorro",5,2,1);
        lista[15]= new Mascotas("Araña",2,2,1);
        lista[16]= new Mascotas("Camello",2,5,1);
        lista[17]= new Mascotas("Mapache",5,4,1);
        lista[18]= new Mascotas("Jirafa",2,5,1);
        lista[19]= new Mascotas("Tortuga",1,2,1);
        lista[20]= new Mascotas("Caracol",2,2,1);
        lista[21]= new Mascotas("Oveja",2,2,1);
        lista[22]= new Mascotas("Conejo",3,2,1);
        lista[23]= new Mascotas("Lobo",3,4,1);
        lista[24]= new Mascotas("Buey",1,4,1);
        lista[25]= new Mascotas("Canguro",1,2,1);
        lista[26]= new Mascotas("Buho",5,3,1);
        return lista[a];
    }
   public void mascotasDisponibles(){
        
        Pelea ir = new Pelea();
         int mascotasDisponibles=0;
         int mascotasEnTienda=0;
         int comidaDisponible=0;
       if(ir.ronda==1){
           mascotasDisponibles=8;
           mascotasEnTienda=3;
          comidaDisponible=3;
       }
       else if(ir.ronda==2 || ir.ronda==3){
           mascotasDisponibles=16;
           mascotasEnTienda=3;
           comidaDisponible=6;
       } 
       else if(ir.ronda==4 || ir.ronda==5 ){
           mascotasDisponibles=27;
           mascotasEnTienda=4;
           comidaDisponible=10;
       } 
       else if(ir.ronda==6||ir.ronda==7){
           mascotasDisponibles=35;
           mascotasEnTienda=4;
           comidaDisponible=13;
       } 
      else if(ir.ronda==8||ir.ronda==9){
           mascotasDisponibles=43;
           mascotasEnTienda=5;
           comidaDisponible=13;
       }
      else if(ir.ronda==10||ir.ronda==11){
           mascotasDisponibles=52;
           mascotasEnTienda=5;
           comidaDisponible=15;
       }
       else if(ir.ronda>=12){
           mascotasDisponibles=54;
           mascotasEnTienda=5;
           comidaDisponible=16;
       } 
       Datos[0]=mascotasDisponibles;
       Datos[1]=mascotasEnTienda;
       Datos[2]=comidaDisponible;
       aux=Datos[1];
    }
   public Mascotas[] mascotasMostradas(){
       Random  rnd = new Random();
       Tienda ir = new Tienda();
       lista2= new Mascotas[Datos[1]];
      
       int posicion=100;
       
        for(int i=0;i<Datos[1];i++){
          posicion = rnd.nextInt(Datos[0] + 0) + 0;
          lista2[i]=ir.baseMascotas(posicion);
          lista2[i].toString();
        }
        
      return lista2;
    }
   public Mascotas[] venderMascotas(Mascotas[] mismascotas){
      
        Scanner leer=new Scanner(System.in);
        String nombre;
        int t=0,p,z=0;
        
        for(int k=0;k<5;k++){
           if(mismascotas[k]!=null){
              mismascotas[k].Mostrar();
              } 
          }
        System.out.println("Escriba el nombre de la mascota a vender");
        nombre= leer.next();
      //contador de posiciones ocupadas por mascotas compradas
        for (Mascotas mismascota : mismascotas) {
            if (mismascota != null) {
                z++;
            }
        }   
        
        for(p=0;p<z;p++){
             if(mismascotas[p].tieneNombre(nombre)){
              if(z==0){
                 System.out.println("No puede vender mas mascotas");
                 break;
              }  
              else{
                 mismascotas[p]=null;
                 t++;
                oro++;
                System.out.println("Mascota vendida");
                break;
              }
             }
             else{
              if(p==z-1){
               System.out.println("No tienes esa mascota");
              }
             }
            }
        
           mismascotas=ordena(mismascotas);
           return mismascotas;
    }
   public Mascotas[] mascotasCompradas(Mascotas[] mismascotas){
     String nombre;
     int z=0;//contador de posiciones utilizadas
     int g=0;
     int x=0,p;
     Scanner leer=new Scanner(System.in);
     
     System.out.println(" ");
     System.out.println("Mascotas en Tienda");
     for(Mascotas ir:lista2){
         if(ir.tieneNombre("nara")){
             
         }
         else{
             ir.Mostrar();
         }
     }
        OUTER:
        while (aux!=0) {
            System.out.println("");
            System.out.println("Oro: "+oro);
            System.out.println("Escriba el nombre de la mascota que va a comprar");
            System.out.println("Escriba 1 para poder vender");
            System.out.println("Escriba 2 para fusionar la mascota");
            System.out.println("Escriba 'FIN' para dejar de comprar");
            nombre= leer.next();
            switch (nombre) {
                case "1":
                    if(mismascotas[0]!=null){
                        
                        mismascotas= venderMascotas(mismascotas);
                        z=0;
                    }else{
                        System.out.println("No tienes mascotas");
                    }     
                    break;
               case "2":
                   Tienda conectar= new Tienda();
                   mismascotas=conectar.fusionar(mismascotas); 
                   mismascotas=ordena(mismascotas);
                   break;
                case "FIN":
                    for(Mascotas ir:mismascotas){
                        if(ir!=null){
                            g++;
                        }
                    }  if (g!=0) {
                        System.out.println(" ");
                        System.out.println("Mis Mascotas");
                        break OUTER;
                    } else {
                        System.out.println("Compre mascotas");
                    }
                    break;
                default:
                    for (Mascotas mismascota : mismascotas) {
                        if (mismascota != null) {
                            z++;
                        }
                    }      
                    for(p=0;p<Datos[1];p++){
                       
                        if(lista2[p].tieneNombre(nombre)){
                            if(z==5){
                                System.out.println("No puede tener mas mascotas");
                                break;
                            }
                            else{
                               if(oro<3){
                                System.out.println("Oro insuficiente");
                                break;
                               }
                               else{
                                mismascotas=ordena(mismascotas);
                                mismascotas[z]=lista2[p];
                                
                                lista2[p]=new Mascotas("nara",2,3,1);
                                aux=aux-1;
                                x++;
                                z=0;
                                oro=oro-3;
                                System.out.println("Mascota comprada");
                                break;
                               }
                                
                            }
                        }
                        else{
                            if(p==Datos[1]-1){
                                System.out.println("Esa mascota no esta en la tienda");
                            }
                        }
                    }      
                    if(mismascotas[x]!=null){
                        mismascotas[x].toString();
                    }       break;
            }
        }
         
     if(x==Datos[1]){
       System.out.println(" ");
       System.out.println("Mis Mascotas");
     }
    
    
     mismascotas=ordena(mismascotas);
      for(int k=0;k<5;k++){
        
       if(mismascotas[k]!=null){
          mismascotas[k].Mostrar();
       } 
     }
      oro=10;
     return  mismascotas;
    }
   public Mascotas[] iaMascotas(){
     Random  rnd = new Random();
     Mascotas[] iamascotas = new Mascotas[5];
     Tienda ir = new Tienda();
     int posicion;
     
     System.out.println(" ");
     System.out.println("Mascotas del rival");
     for(int i=0;i<Datos[1];i++){
          posicion = rnd.nextInt(Datos[0] + 0) + 0;
          iamascotas[i]=ir.baseMascotas(posicion);
          System.out.println(iamascotas[i].toString());
     }
     return iamascotas;
   }
   public Mascotas[] ordena(Mascotas[] mismascotas){
      for(int x=0;x<5;x++){
       if(mismascotas[x]==null){
           if( x!=4){
             if(mismascotas[x+1]!=null){
               mismascotas[x]=mismascotas[x+1];
               mismascotas[x+1]=null;
             }
           }
           
       }
      }
       return mismascotas;
   }
   public Mascotas[] fusionar(Mascotas[] misMascotas){
       int z=0,aux=10,conteo=0,conteo2=0;
       String nombre;
        Scanner leer=new Scanner(System.in);
        for(Mascotas ir:misMascotas){
            if(ir!=null){
                ir.Mostrar();
            }
        }
        
        System.out.println("Escriba el nombre de la mascota a fusionar");
        nombre= leer.next();
              for (int j=0;j<5;j++) {
                 if (misMascotas[j] != null) {
                     if(misMascotas[j].tieneNombre(nombre)){
                            z++;
                       if(z==1){
                           aux=j;
                       }     
                       if(z==2){
                           misMascotas[j]=null;
                           if(misMascotas[aux].nivel()==1 ){
                               misMascotas[aux].setNivel(misMascotas[aux].nivel()+1);
                               System.out.println(misMascotas[aux].obtenerNombre()+" sube a nivel 2");
                                 break;
                           }
                           else if(misMascotas[aux].nivel()==2){
                               misMascotas[aux].setNivel(misMascotas[aux].nivel()+0.5);
                                 break;
                           }
                           else if(misMascotas[aux].nivel()==2.5){
                               misMascotas[aux].setNivel(misMascotas[aux].nivel()+0.25);
                                 break;
                           }
                           else if(misMascotas[aux].nivel()==2.75){
                               misMascotas[aux].setNivel(misMascotas[aux].nivel()+0.25);
                                 break;
                           }
                           else if(misMascotas[aux].nivel()==3){
                                System.out.println(misMascotas[aux].obtenerNombre()+" sube a nivel 3");
                                 break;
                           }
                       }
                  }
                     
              }  
              else{
                      conteo2++;
                         if(conteo2==5){
                               System.out.println("No tienes mascotas");
                             conteo=0;
                         }
                 }
                 
            }
      
           if(z==1){
              System.out.println("No es posible fusionar");
               
            }
      
       return misMascotas;
   }
}
