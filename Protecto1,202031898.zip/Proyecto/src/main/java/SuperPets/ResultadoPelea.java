/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SuperPets;

/**
 *
 * @author Colop
 */
public class ResultadoPelea {
    protected int ronda;
    protected Mascotas[] jugador1;
    protected Mascotas[] jugador2;
    protected int partidasGanadas;
    protected int partidasPerdidas; 
    protected int vida;
    public ResultadoPelea(Mascotas[] jugador1, Mascotas[] jugador2, int ronda, int partidasGanadas,int partidasPerdidas,int vida ){
        this.ronda=ronda;
        this.jugador1=jugador1;
        this.jugador2=jugador2;
        this.partidasGanadas=partidasGanadas;
        this.partidasPerdidas=partidasPerdidas;
        this.vida=vida;
    }
    public void Derrota(){
    
    }
    public void Victoria(){
     
    }
    public void Empate(){
        
    }
}
